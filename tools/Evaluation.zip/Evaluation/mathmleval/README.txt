
We will provide a tool for symbol level evaluation of systems that generate LaTex strings by converting LaTex to MathML. This tool will be released soon.

-------------------------
Mahshad, March 2, 2019
